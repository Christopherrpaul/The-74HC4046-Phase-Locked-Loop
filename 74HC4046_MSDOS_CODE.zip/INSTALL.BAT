echo off
rem Installs contents of the disk in a directory on C: given in the command line.
rem As an example: INSTALL 4046 will result in the following:
rem     - a directory C:\4046 will be made
rem     - all files on this disk will be copied to C:\4046
rem     - documentation files (READ.ME and VCO_CALC.TXT will be shown
rem If no directory name is specified, the files will be copied to C:\PLL
set dir=%1
if %dir%.==. set dir=PLL
echo.
echo.
echo.
echo.
echo.
echo.
echo.
echo.
echo                PPPP   H   H  I  L      I  PPPP    SSSS
echo                P   P  H   H  I  L      I  P   P  S
echo                PPPP   HHHHH  I  L      I  PPPP    SSS
echo                P      H   H  I  L      I  P          S
echo                P      H   H  I  LLLLL  I  P      SSSS
echo.
echo.
echo            PLL DESIGN PROGRAM COPY FACILITY TO THE HARD DISK
echo.
echo.
echo.
echo.
echo.
echo.
echo.
echo.
pause
echo.
echo.
echo            PHILIPS SEMICONDUCTORS NIJMEGEN THE NETHERLANDS
echo.
echo            PRODUCT CONCEPT & APPLICATION LABORATORY EINDHOVEN.
echo.
echo            This is a batchfile that copies the PLL design
echo            program files to your hard disk.
echo            The program will make the following directory :
echo.
echo            C:\%dir%
echo.
echo            All the graphic driver files are already included in
echo            the main program in order to ensure proper activating
echo            of your graphics card.
echo            The program can also be started directly from diskette
echo            in the A or B drive, but it will take some more time
echo            to load it into memory.
echo.
echo.           You may also install the programs yourself. The program
echo            works from any directory.
echo.
echo            If you want to cancel the copy facility now,
echo            press Control-C, and terminate this procedure.
echo.
pause
echo.
echo.
echo.
echo.
echo Starting....................
md c:\%dir%
echo.
echo.
copy *.* c:\%dir%
c:
cd \%dir%
readme
