echo off
cls
type readme|more
echo Press a key to continue
echo.
pause >nul
type VCO_CALC.TXT | more
echo Press a key to continue
echo.
pause >nul
cls
echo.
echo.
echo       ------------------------------------------------------------------
echo       The program INSTALL.BAT will install the program onto a hard disk.
echo.
echo       Enter:    INSTALL DIRNAME
echo.
echo       where DIRNAME is the name of the directory you wish to use. If you
echo       don't specify DIRNAME, then the directory name  PLL  will be used.
echo       ------------------------------------------------------------------
echo       It is advised to copy the files  VCO4046A.WK1  and  VCO9046A.WK1
echo       to your local 1-2-3 data directory or  data disk using  standard
echo       DOS commands.
echo       ------------------------------------------------------------------
